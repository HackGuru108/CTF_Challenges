# PowerShell startup script for Challenge 4: Initech SynergyDesk
Write-Host "[*] Building and starting Initech SynergyDesk container..." -ForegroundColor Cyan
docker compose up -d --build
Write-Host "`n[+] Challenge 4 is live at: http://localhost:8005" -ForegroundColor Green
Write-Host "[*] To stop, run: docker compose down`n" -ForegroundColor Yellow
