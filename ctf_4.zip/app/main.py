import os
import json
from fastapi import FastAPI, Request, Response, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

app = FastAPI(title="Initech SynergyDesk Enterprise v9.4")
templates = Jinja2Templates(directory=os.path.join(os.path.dirname(__file__), "templates"))

FLAG = os.getenv("FLAG", "CTF{c0rp0r4t3_syn3rgy_b0nus_4ppr0v3d_2026}")

# Default employee profile for Milton
DEFAULT_EMPLOYEE = {
    "employee_id": "EMP-404-MILTON",
    "name": "Milton Waddams",
    "department": "Basement Storage B",
    "role": "Cubicle_Associate",
    "is_c_suite": False,
    "synergy_score": 12,
    "stapler_status": "Swingline 747 (Missing)",
    "pto_days_remaining": -4,
    "performance_status": "Pre-PIP Review"
}

EMPLOYEES = {}

def get_employee(session_id: str):
    if session_id not in EMPLOYEES:
        EMPLOYEES[session_id] = DEFAULT_EMPLOYEE.copy()
    return EMPLOYEES[session_id]

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/api/employee/profile")
async def get_profile(request: Request):
    session_id = request.cookies.get("corp_session", "milton_cookie")
    emp = get_employee(session_id)
    resp = JSONResponse({"success": True, "employee": emp})
    if "corp_session" not in request.cookies:
        resp.set_cookie("corp_session", "milton_cookie")
    return resp

# Vulnerable Endpoint: Unsafe dictionary update (Mass Assignment / Parameter Pollution)
@app.post("/api/employee/update-kpi")
async def update_kpi(request: Request):
    session_id = request.cookies.get("corp_session", "milton_cookie")
    emp = get_employee(session_id)
    
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "Invalid JSON body"}, status_code=400)

    # VULNERABILITY 1: Mass assignment blindly unpacks all JSON keys into employee object!
    # Sending {"role": "Chief_Executive_Officer", "is_c_suite": true, "synergy_score": 9999} elevates the user.
    emp.update(body)
    
    return {
        "success": True,
        "message": "Corporate KPI telemetry synchronized with HR Synergy Grid.",
        "employee": emp
    }

# Tricky Endpoint: Requires C-Suite role + Boardroom Header or custom HTTP method SYNERGIZE
@app.api_route("/api/executive/bonus-vault", methods=["GET", "POST", "SYNERGIZE", "OPTIONS"])
async def bonus_vault(request: Request):
    session_id = request.cookies.get("corp_session", "milton_cookie")
    emp = get_employee(session_id)

    # Check 1: Role check (Requires mass assignment bypass)
    if not emp.get("is_c_suite") and emp.get("role") not in ["Chief_Executive_Officer", "Executive_VP", "Board_Member"]:
        return JSONResponse({
            "error": "ACCESS DENIED: 403 Forbidden. This endpoint is strictly reserved for C-Suite Leadership. Submit a ticket to HR to appeal your synergy grade.",
            "hint": "Check /api/compliance/audit-log for boardroom requirements."
        }, status_code=403)

    # Check 2: Tricky corporate boardroom origin check or HTTP Verb check
    forwarded = request.headers.get("X-Forwarded-For", "")
    boardroom_token = request.headers.get("X-Boardroom-Token", "")
    method = request.method

    # Allows access if internal loopback header OR custom HTTP verb SYNERGIZE
    is_internal_origin = (forwarded in ["127.0.0.1", "localhost"] or boardroom_token == "EXECUTIVE_PARACHUTE_9901")
    is_synergize_verb = (method == "SYNERGIZE")

    if not (is_internal_origin or is_synergize_verb):
        return JSONResponse({
            "error": "SECURITY AUDIT: Request did not originate from the Executive Boardroom (missing X-Forwarded-For: 127.0.0.1 / X-Boardroom-Token) OR valid corporate verb 'SYNERGIZE'.",
            "current_method": method,
            "allowed_methods": ["GET", "POST", "SYNERGIZE"]
        }, status_code=401)

    return {
        "success": True,
        "message": "Executive Golden Parachute & Bonus Package Approved by the Board of Directors!",
        "executive": emp.get("name"),
        "bonus_amount": "$4,200,000 USD (Stock Options)",
        "flag": FLAG
    }

@app.get("/api/compliance/audit-log")
async def audit_log():
    return {
        "system": "Initech Automated Synergy Compliance Monitor v9.4",
        "recent_audit_events": [
            {"event": "TPS Report Verification", "status": "FAILED", "notes": "Did you get the memo about the new cover sheet?"},
            {"event": "Boardroom Policy Check", "status": "INFO", "notes": "C-Suite endpoints require internal origin header (X-Forwarded-For: 127.0.0.1) or custom enterprise verb (SYNERGIZE)."},
            {"event": "Milton Desk Relocation", "status": "COMPLETED", "notes": "Moved to basement storage B due to space optimization."}
        ]
    }

@app.post("/api/reset")
async def reset_corp(request: Request):
    session_id = request.cookies.get("corp_session", "milton_cookie")
    EMPLOYEES[session_id] = DEFAULT_EMPLOYEE.copy()
    return {"success": True, "employee": EMPLOYEES[session_id]}
