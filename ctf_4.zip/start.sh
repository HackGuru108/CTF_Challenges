#!/usr/bin/env bash
# Quickstart script for Challenge 4: Initech SynergyDesk
set -e
echo "[*] Building and starting Initech SynergyDesk container..."
docker compose up -d --build
echo ""
echo "[+] Challenge 4 is live at: http://localhost:8005"
echo "[*] To stop, run: docker compose down"
