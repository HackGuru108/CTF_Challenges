import re
import ipaddress
from urllib.parse import urlparse
from flask import Flask, request, jsonify, render_template
import requests

app = Flask(__name__)

# Naive IP/Hostname blacklist filter
BLACKLIST_PATTERNS = [
    r"^localhost$",
    r"^127\.\d+\.\d+\.\d+$",
    r"^0\.0\.0\.0$",
    r"^192\.168\.\d+\.\d+$",
    r"^10\.\d+\.\d+\.\d+$",
    r"^172\.(1[6-9]|2[0-9]|3[0-1])\.\d+\.\d+$",
    r"^169\.254\.\d+\.\d+$"
]

def is_blocked(url: str) -> (bool, str):
    parsed = urlparse(url)
    if not parsed.scheme or parsed.scheme not in ["http", "https"]:
        return True, "Invalid scheme. Only http:// and https:// are supported."
    
    hostname = parsed.hostname
    if not hostname:
        return True, "Invalid target host."
    
    # Check string regex blacklist
    for pattern in BLACKLIST_PATTERNS:
        if re.search(pattern, hostname, re.IGNORECASE):
            return True, f"Access to '{hostname}' is forbidden by corporate security policies."

    return False, ""

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/ping", methods=["POST"])
def ping_webhook():
    data = request.get_json(force=True, silent=True) or {}
    target_url = data.get("url", "").strip()

    if not target_url:
        return jsonify({"success": False, "error": "Missing 'url' parameter"}), 400

    blocked, reason = is_blocked(target_url)
    if blocked:
        return jsonify({"success": False, "error": f"Security Guardrail Triggered: {reason}"}), 403

    try:
        # Perform HTTP request on behalf of the server
        resp = requests.get(
            target_url,
            timeout=4,
            headers={"User-Agent": "LinkPulse-WebhookBot/3.0"}
        )
        
        return jsonify({
            "success": True,
            "status_code": resp.status_code,
            "headers": dict(resp.headers),
            "body": resp.text[:4096] # Return first 4KB of response
        })
    except requests.exceptions.Timeout:
        return jsonify({"success": False, "error": "Request timed out connecting to target."}), 504
    except Exception as e:
        return jsonify({"success": False, "error": f"Connection error: {str(e)}"}), 502

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
