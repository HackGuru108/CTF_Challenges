#!/usr/bin/env bash
# Quickstart script for Challenge 2: LinkPulse (SSRF)
set -e
echo "[*] Building and starting LinkPulse containers..."
docker compose up -d --build
echo ""
echo "[+] Challenge 2 is live at: http://localhost:8002"
echo "[*] To stop, run: docker compose down"
