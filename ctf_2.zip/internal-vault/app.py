import os
from flask import Flask, request, jsonify

app = Flask(__name__)

FLAG = os.getenv("FLAG", "CTF{ssrf_t0_1nt3rn4l_p1v0t_fl4g_2026}")
INTERNAL_SECRET_TOKEN = "corp_internal_secret_99812"

@app.route("/")
def home():
    return jsonify({
        "service": "Core Security Vault (Internal Network Gateway)",
        "version": "v2.1.4-private",
        "notice": "Access strictly prohibited from public internet.",
        "documentation": "/api/docs"
    })

@app.route("/api/docs")
def docs():
    return jsonify({
        "endpoints": [
            {
                "path": "/api/v1/status",
                "method": "GET",
                "description": "Cluster node telemetry"
            },
            {
                "path": "/api/v1/admin/flag",
                "method": "GET",
                "description": "Master Vault Flag Exfiltration Endpoint",
                "auth": {
                    "header": "X-Vault-Auth",
                    "or_query_param": "token",
                    "required_token": INTERNAL_SECRET_TOKEN
                }
            }
        ]
    })

@app.route("/api/v1/status")
def status():
    return jsonify({
        "cluster": "internal-prod-zone-1",
        "active_nodes": 8,
        "vault_encrypted": True,
        "load": "0.12"
    })

@app.route("/api/v1/admin/flag")
def get_flag():
    token = request.headers.get("X-Vault-Auth") or request.args.get("token")
    if token == INTERNAL_SECRET_TOKEN:
        return jsonify({
            "status": "authorized",
            "message": "Flag retrieved from secure enclave.",
            "flag": FLAG
        })
    
    return jsonify({
        "status": "unauthorized",
        "error": "Missing or invalid internal authentication token."
    }), 401

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
