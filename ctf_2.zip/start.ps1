# PowerShell startup script for Challenge 2: LinkPulse (SSRF)
Write-Host "[*] Building and starting LinkPulse containers..." -ForegroundColor Cyan
docker compose up -d --build
Write-Host "`n[+] Challenge 2 is live at: http://localhost:8002" -ForegroundColor Green
Write-Host "[*] To stop, run: docker compose down`n" -ForegroundColor Yellow
