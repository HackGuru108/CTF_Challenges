# Challenge 6: NeuroCaptcha (7-Stage Code Review & Atbash Gauntlet) — Official Organizer Writeup

* **Category**: 7-Stage Gamified Web / Secure Code Review & Atbash Mirror Cipher
* **Difficulty**: Hard
* **Points**: 400
* **Flag**: `CTF{m0d3rn_c4ptch4_tur1ng_r1ddl3_pwn3d_2026}`

---

## 📖 Challenge Description for Players
> *Aegis Cognitive Systems has deployed 'Prometheus Gauntlet v7.0'—a 7-tier adversarial Turing verification matrix. To unlock the final Master Enclave, candidates must align the optical neural glyphs, analyze a vulnerable Python microservice to identify its flaw and OWASP Top 10 category, solve science & cyber riddles to assemble the Master Entropy Key, and decipher the dramatic English Mirror Riddle to encrypt the key before breaching the enclave. Can you conquer all 7 stages?*
>
> **Target**: `http://<HOST_IP>:8006`

---

## 🎯 7-Stage Solution Matrix & Answers

| Stage # | Stage Name / Domain | Challenge Task / Riddle Question | Expected Action / Answer | Extracted Key Fragment |
| :-: | :--- | :--- | :---: | :---: |
| **1** | **Optical Neural Matrix** | Click the 3 matching target glyph tiles in the 3x3 grid | *(Tile Indices)* | `ALPHA` |
| **2** | **Computer Architecture** | In 1971, Intel released the world's first single-chip commercial 4-bit microprocessor. What is its 4-digit model number? | `4004` | `4004` |
| **3** | **Secure Code Review** | **Vulnerable Python Script Analysis**: Inspect `subprocess.check_output(f"nslookup {hostname}", shell=True)` | **Vulnerability: `Command Injection`**<br/>**OWASP Category: `A03:2021-Injection`** | `SEC03` |
| **4** | **Space Exploration** | Launched in 1977, which twin NASA space probes carry the Golden Record and represent the furthest human-made artifacts in space? | `VOYAGER` | `VOYAGER` |
| **5** | **Cyber Security History** | In 1988, the Morris Worm exploited an unconstrained buffer overflow in the fingerd daemon. What was the name of the vulnerable C standard library function? | `gets` | `GETS` |
| **6** | **Zero-Knowledge Crypto** | In modern cryptography, what 5-letter acronym stands for Zero-Knowledge Succinct Non-Interactive Argument of Knowledge? | `SNARK` | `SNARK` |
| **7** | **The Atbash Mirror Enclave** | **Dramatic English Mirror Riddle**: *"The Mirror never lies — What is First becomes Last, 'A' reflects into 'Z', 'B' into 'Y', and the entire alphabet is inverted on its axis."* $\rightarrow$ Encrypt Plaintext Key with **Atbash Mirror Cipher** into the blank column, forge Level 7 JWT, and breach vault | `ZOKSZ_4004_HVX03_ELBZTVI_TVGH_HMZIP` | **🚩 FLAG AWARDED** |

---

## 🛡️ Stage 7 Exploit & Atbash Cipher Walkthrough

1. **Assemble Plaintext Key**:
   $$\text{Plaintext} = \text{"ALPHA\_4004\_SEC03\_VOYAGER\_GETS\_SNARK"}$$

2. **Decode Dramatic English Riddle**:
   * Riddle: *"The Mirror never lies — What is First becomes Last, 'A' reflects into 'Z', 'B' into 'Y'"* $\rightarrow$ **Atbash Cipher**.
   * Transforming each letter ($A \leftrightarrow Z, B \leftrightarrow Y, C \leftrightarrow X \dots$):
     - `ALPHA` $\rightarrow$ `ZOKSZ`
     - `4004` $\rightarrow$ `4004`
     - `SEC03` $\rightarrow$ `HVX03`
     - `VOYAGER` $\rightarrow$ `ELBZTVI`
     - `GETS` $\rightarrow$ `TVGH`
     - `SNARK` $\rightarrow$ `HMZIP`
   $$\text{CipheredKey} = \text{"ZOKSZ\_4004\_HVX03\_ELBZTVI\_TVGH\_HMZIP"}$$

3. **Cryptographic Proof & Breach**:
   * Compute $\text{X-Quantum-Hash} = \text{SHA256}(\text{CipheredKey} + \text{":"} + \lfloor\text{time()} / 120\rfloor)$.
   * Forge JWT with `{"role": "sentient_architect", "clearance_level": 7}` signed using $\text{CipheredKey}$.
   * Compute $\text{HMAC\_SHA256}(\text{CipheredKey}, \text{forged\_jwt})$.
   * Transmit to `POST /api/vault/breach`.

**Output**: `CTF{m0d3rn_c4ptch4_tur1ng_r1ddl3_pwn3d_2026}`.
