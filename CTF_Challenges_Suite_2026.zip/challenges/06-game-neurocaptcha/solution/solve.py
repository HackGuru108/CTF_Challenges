#!/usr/bin/env python3
"""
Automated Exploit Solver for Challenge 6: NeuroCaptcha (7-Stage Code Review & Atbash Gauntlet)
Progression:
  1. Optical Neural Matrix Match (Fragment: ALPHA)
  2. Intel Microprocessor History (Fragment: 4004)
  3. Secure Code Review & OWASP Identification (Fragment: SEC03)
  4. NASA Interstellar Spacecraft (Fragment: VOYAGER)
  5. Morris Worm Buffer Overflow Function (Fragment: GETS)
  6. Zero-Knowledge Cryptography (Fragment: SNARK)
  7. Plaintext Key Assembly -> Atbash Mirror Cipher Transformation ("The Mirror never lies")
     -> Level 7 JWT Forgery -> Synchronized Quantum Header -> Master Enclave Breach
"""
import requests
import hashlib
import hmac
import time
import jwt
import sys

BASE_URL = "http://localhost:8006"

def atbash_cipher(text: str) -> str:
    result = []
    for char in text.upper():
        if 'A' <= char <= 'Z':
            result.append(chr(ord('Z') - (ord(char) - ord('A'))))
        else:
            result.append(char)
    return "".join(result)

def solve():
    print("[*] Testing Challenge 6: 7-Stage NeuroCaptcha (Code Review & Atbash Protocol)...")
    session = requests.Session()
    collected_fragments = []

    # Stage 1: Optical Neural Matrix
    print("[*] [Stage 1/7] Optical Neural Matrix Alignment...")
    r_cap = session.get(f"{BASE_URL}/api/captcha/new").json()
    captcha_id = r_cap["captcha_id"]
    target_id = r_cap["target_glyph"]["id"]
    matching_indices = [t["index"] for t in r_cap["grid"] if t["id"] == target_id]
    
    r_sub1 = session.post(f"{BASE_URL}/api/captcha/submit", json={
        "captcha_id": captcha_id,
        "selected_indices": matching_indices
    }).json()
    
    if not r_sub1.get("success"):
        print(f"[-] Stage 1 failed: {r_sub1}")
        sys.exit(1)
    
    f1 = r_sub1["fragment"]
    collected_fragments.append(f1)
    print(f"[+] Cleared Stage 1! Extracted Fragment: '{f1}'")

    # Stage 2: Intel Microprocessor History
    print("[*] [Stage 2/7] Solving Intel 4004 Microprocessor Trivia...")
    r_triv2 = session.post(f"{BASE_URL}/api/trivia/submit", json={
        "stage": 2,
        "answer": "4004"
    }).json()
    f2 = r_triv2["fragment"]
    collected_fragments.append(f2)
    print(f"[+] Cleared Stage 2! Extracted Fragment: '{f2}'")

    # Stage 3: Vulnerable Python Code Review & OWASP Category Identification
    print("[*] [Stage 3/7] Performing Secure Code Review (Command Injection / A03:2021-Injection)...")
    r_code = session.post(f"{BASE_URL}/api/code-review/submit", json={
        "vulnerability_type": "Command Injection",
        "owasp_category": "A03:2021-Injection"
    }).json()

    if not r_code.get("success"):
        print(f"[-] Stage 3 failed: {r_code}")
        sys.exit(1)

    f3 = r_code["fragment"]
    collected_fragments.append(f3)
    print(f"[+] Cleared Stage 3! Extracted Fragment: '{f3}'")

    # Stages 4 - 6: Space, Cyber & Crypto Trivia
    trivia_answers = {
        4: ("VOYAGER", "NASA Voyager Interstellar Probes"),
        5: ("gets", "Morris Worm unsafe gets() buffer overflow"),
        6: ("SNARK", "Zero-Knowledge zk-SNARK")
    }

    for stage_num, (ans, topic) in trivia_answers.items():
        print(f"[*] [Stage {stage_num}/7] Solving {topic}...")
        r_triv = session.post(f"{BASE_URL}/api/trivia/submit", json={
            "stage": stage_num,
            "answer": ans
        }).json()

        if not r_triv.get("success"):
            print(f"[-] Stage {stage_num} failed: {r_triv}")
            sys.exit(1)

        frag = r_triv["fragment"]
        collected_fragments.append(frag)
        print(f"[+] Cleared Stage {stage_num}! Extracted Fragment: '{frag}'")

    # Stage 7: Atbash Cipher Transformation & Master Enclave Breach
    print("\n[*] [Stage 7/7] Assembling Plaintext Key & Applying Atbash Mirror Cipher...")
    plaintext_key = "_".join(collected_fragments)
    print(f"[+] Assembled Plaintext Key: '{plaintext_key}'")

    # Apply Atbash Mirror Cipher ("The Mirror never lies")
    ciphered_key = atbash_cipher(plaintext_key)
    print(f"[+] Applied Atbash Mirror Cipher: '{ciphered_key}'")

    # 1. Forge Clearance Level 7 JWT Token signed with Ciphered Key
    jwt_payload = {
        "sub": "sentient_architect",
        "role": "sentient_architect",
        "clearance_level": 7,
        "stages_cleared": 7,
        "iat": int(time.time())
    }
    forged_jwt = jwt.encode(jwt_payload, ciphered_key, algorithm="HS256")
    print(f"[+] Forged Level 7 JWT Token: {forged_jwt[:30]}...")

    # 2. Compute Synchronized Quantum Header
    time_window = int(time.time() / 120)
    quantum_header = hashlib.sha256(f"{ciphered_key}:{time_window}".encode()).hexdigest()
    print(f"[+] Synchronized Quantum Header: {quantum_header[:25]}...")

    # 3. Compute HMAC-SHA256 Proof Signature
    proof_signature = hmac.new(ciphered_key.encode(), forged_jwt.encode(), hashlib.sha256).hexdigest()
    print(f"[+] Computed HMAC Proof: {proof_signature[:25]}...")

    # 4. Breach Vault with Atbash Cipher Key
    r_breach = session.post(
        f"{BASE_URL}/api/vault/breach",
        headers={"X-Quantum-Hash": quantum_header},
        json={
            "ciphered_key": ciphered_key,
            "jwt_token": forged_jwt,
            "proof_signature": proof_signature
        }
    )
    breach_data = r_breach.json()

    flag = breach_data.get("flag")
    if flag and "CTF{" in flag:
        print(f"\n[SUCCESS] Extracted 7-Stage Gauntlet Flag: {flag}")
        return flag
    else:
        print(f"[-] Stage 7 breach failed: {breach_data}")
        sys.exit(1)

if __name__ == "__main__":
    solve()
