import os
import time
import random
import hmac
import hashlib
import jwt
from fastapi import FastAPI, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

app = FastAPI(title="NeuroCaptcha: 7-Stage Sentience Gauntlet (Secure Code Review & Atbash)")
templates = Jinja2Templates(directory=os.path.join(os.path.dirname(__file__), "templates"))

FLAG = os.getenv("FLAG", "CTF{n3ur0_7_st4g3_4tb4sh_c0d3_s3c_m4st3r_2026}")

# 7 Stage Configuration & Trivia Database
STAGE_QUESTIONS = {
    2: {
        "category": "Computer Architecture & Silicon History",
        "question": "In 1971, Intel launched the world's first single-chip commercial 4-bit microprocessor. What is its 4-digit model number?",
        "accepted_answers": ["4004", "intel 4004", "i4004"],
        "fragment": "4004"
    },
    4: {
        "category": "Space Exploration & Deep Space Computing",
        "question": "Launched in 1977, which twin NASA interstellar space probes carry the Golden Record and represent the furthest human-made artifacts in interstellar space?",
        "accepted_answers": ["voyager", "voyager 1", "voyager 2", "the voyager probes"],
        "fragment": "VOYAGER"
    },
    5: {
        "category": "Cybersecurity & Internet Network History",
        "question": "In 1988, the Morris Worm disabled 10% of the ARPANET by exploiting an unconstrained buffer overflow in the fingerd daemon. What was the name of the vulnerable C standard library function?",
        "accepted_answers": ["gets", "gets()"],
        "fragment": "GETS"
    },
    6: {
        "category": "Modern Zero-Knowledge Cryptography",
        "question": "In modern cryptography, what 5-letter acronym stands for Zero-Knowledge Succinct Non-Interactive Argument of Knowledge?",
        "accepted_answers": ["snark", "zk-snark", "zksnark"],
        "fragment": "SNARK"
    }
}

# Plaintext Master Key assembled across all 7 stages:
# Stage 1: ALPHA
# Stage 2: 4004
# Stage 3: SEC03 (From Stage 3 Code Review & OWASP Identification)
# Stage 4: VOYAGER
# Stage 5: GETS
# Stage 6: SNARK
PLAINTEXT_MASTER_KEY = "ALPHA_4004_SEC03_VOYAGER_GETS_SNARK"

# Atbash Cipher Translation
def atbash_cipher(text: str) -> str:
    result = []
    for char in text.upper():
        if 'A' <= char <= 'Z':
            result.append(chr(ord('Z') - (ord(char) - ord('A'))))
        else:
            result.append(char)
    return "".join(result)

CIPHERED_MASTER_KEY = atbash_cipher(PLAINTEXT_MASTER_KEY)
# "ZOKSZ_4004_HVX03_ELBZTVI_TVGH_HMZIP"

GLYPHS = [
    {"id": "atom", "name": "Quantum Core", "icon": "fa-atom"},
    {"id": "brain", "name": "Neural Synapse", "icon": "fa-brain"},
    {"id": "microchip", "name": "Silicon Node", "icon": "fa-microchip"},
    {"id": "shield", "name": "Cyber Aegis", "icon": "fa-shield-halved"},
    {"id": "satellite", "name": "Deep Space Relay", "icon": "fa-satellite"},
    {"id": "dna", "name": "Biometric Genome", "icon": "fa-dna"}
]

ACTIVE_CAPTCHAS = {}

# Vulnerable Code Snippet for Stage 3
VULNERABLE_CODE_SNIPPET = """# Target Microservice: Document & System Diagnostic API
import subprocess
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/api/diagnostics/lookup', methods=['POST'])
def run_host_diagnostic():
    hostname = request.json.get('target_host', '')
    
    # Executing external diagnostic command using system shell
    cmd = f"nslookup {hostname}"
    output = subprocess.check_output(cmd, shell=True)
    
    return jsonify({"status": "success", "result": output.decode('utf-8')})
"""

class CaptchaSubmitRequest(BaseModel):
    captcha_id: str
    selected_indices: list[int]

class CodeReviewRequest(BaseModel):
    vulnerability_type: str
    owasp_category: str

class TriviaSubmitRequest(BaseModel):
    stage: int
    answer: str

class VaultBreachRequest(BaseModel):
    ciphered_key: str
    jwt_token: str
    proof_signature: str

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {
        "request": request,
        "questions": STAGE_QUESTIONS
    })

# API endpoint to retrieve target microservice source code for Stage 3 audit
@app.get("/api/code-review/source")
async def get_code_source():
    return {
        "filename": "microservice_diagnostics.py",
        "language": "python",
        "code": VULNERABLE_CODE_SNIPPET
    }

# Stage 1: Generate Visual Image / Glyph Matrix
@app.get("/api/captcha/new")
async def new_captcha():
    captcha_id = hashlib.sha256(f"{time.time()}_{random.random()}".encode()).hexdigest()[:16]
    target = random.choice(GLYPHS)
    
    grid = []
    correct_indices = []
    target_positions = set(random.sample(range(9), 3))
    
    for i in range(9):
        if i in target_positions:
            grid.append(target)
            correct_indices.append(i)
        else:
            other = random.choice([g for g in GLYPHS if g["id"] != target["id"]])
            grid.append(other)
            
    ACTIVE_CAPTCHAS[captcha_id] = {
        "target": target["id"],
        "correct_indices": sorted(correct_indices),
        "created_at": time.time()
    }

    return {
        "captcha_id": captcha_id,
        "target_glyph": target,
        "instruction": f"Identify & select all 3 tiles containing: {target['name']}",
        "grid": [{"index": i, "icon": tile["icon"], "id": tile["id"]} for i, tile in enumerate(grid)]
    }

# Stage 1 Submit
@app.post("/api/captcha/submit")
async def submit_captcha(req: CaptchaSubmitRequest):
    if req.captcha_id not in ACTIVE_CAPTCHAS:
        return JSONResponse({"error": "Expired or invalid matrix. Refresh matrix."}, status_code=400)

    captcha = ACTIVE_CAPTCHAS[req.captcha_id]
    submitted = sorted(req.selected_indices)

    if submitted == captcha["correct_indices"]:
        del ACTIVE_CAPTCHAS[req.captcha_id]
        
        initial_token = jwt.encode({
            "sub": "neural_candidate",
            "clearance_level": 1,
            "stage_cleared": 1,
            "iat": int(time.time())
        }, "interim_stage_1_seed", algorithm="HS256")

        return {
            "success": True,
            "message": "Stage 1 Cleared: Optical Neural Alignment Confirmed.",
            "fragment": "ALPHA",
            "next_stage": 2,
            "token": initial_token
        }
    else:
        return JSONResponse({"error": "Optical pattern mismatch! Select all 3 matching glyphs."}, status_code=400)

# Stage 3: Vulnerable Code Review & OWASP Classification Task
@app.post("/api/code-review/submit")
async def submit_code_review(req: CodeReviewRequest):
    vuln_clean = req.vulnerability_type.strip().lower()
    owasp_clean = req.owasp_category.strip().lower()

    # Check Vulnerability Type
    valid_vulns = [
        "command injection", "os command injection", "command execution", 
        "os command execution", "rce", "remote code execution", "shell injection"
    ]
    is_vuln_valid = any(v in vuln_clean for v in valid_vulns)

    # Check OWASP Category
    valid_owasp = [
        "a03", "a03:2021", "a03:2021-injection", "injection", 
        "a03 injection", "a3", "a3:2021", "a03:2021 - injection"
    ]
    is_owasp_valid = any(o in owasp_clean for o in valid_owasp)

    if is_vuln_valid and is_owasp_valid:
        return {
            "success": True,
            "message": "Security Analysis Verified! Correct vulnerability and OWASP classification identified.",
            "fragment": "SEC03",
            "next_stage": 4
        }
    else:
        err_msg = []
        if not is_vuln_valid:
            err_msg.append("Vulnerability Type incorrect.")
        if not is_owasp_valid:
            err_msg.append("OWASP Top 10 Category incorrect.")
        
        return JSONResponse({
            "error": "❌ Code Review Verification Failed: " + " ".join(err_msg)
        }, status_code=400)

# Stages 2, 4, 5, 6: Science, Space & Tech Trivia Endpoints
@app.post("/api/trivia/submit")
async def submit_trivia(req: TriviaSubmitRequest):
    if req.stage not in STAGE_QUESTIONS:
        return JSONResponse({"error": f"Invalid stage number: {req.stage}."}, status_code=400)

    stage_info = STAGE_QUESTIONS[req.stage]
    cleaned_ans = req.answer.strip().lower()

    if any(cleaned_ans == acc.lower() for acc in stage_info["accepted_answers"]):
        next_stg = req.stage + 1
        return {
            "success": True,
            "stage_cleared": req.stage,
            "message": f"Correct! Stage {req.stage} verified.",
            "fragment": stage_info["fragment"],
            "next_stage": next_stg
        }
    else:
        return JSONResponse({
            "error": f"Incorrect answer for Stage {req.stage}. Review the clue carefully."
        }, status_code=400)

# Stage 7: The Master Cryptographic Enclave (Requires Transformed Mirror Key)
@app.post("/api/vault/breach")
async def breach_vault(req: VaultBreachRequest, request: Request):
    submitted_cipher_key = req.ciphered_key.strip().upper()

    # 1. Plaintext warning
    if submitted_cipher_key == PLAINTEXT_MASTER_KEY:
        return JSONResponse({
            "error": "❌ ENCRYPTION REQUIRED: You submitted the raw plaintext key! The Enclave only accepts the key transformed according to the ancient Riddle of the Mirror.",
            "riddle_hint": "Reflect upon the riddle: 'What is First becomes Last, and what begins the alphabet must gaze upon its end...'"
        }, status_code=400)

    # 2. Verify Ciphered Master Key
    if submitted_cipher_key != CIPHERED_MASTER_KEY:
        return JSONResponse({
            "error": "❌ INVALID KEY! The key does not match the mirror transformation of your assembled fragments. Review the riddle carefully."
        }, status_code=400)

    # 3. Check Time-Synchronized Quantum Header
    time_window = int(time.time() / 120)
    expected_header_hash = hashlib.sha256(f"{CIPHERED_MASTER_KEY}:{time_window}".encode()).hexdigest()
    client_quantum_header = request.headers.get("X-Quantum-Hash", "")

    if client_quantum_header.lower() != expected_header_hash.lower():
        if not client_quantum_header:
            return JSONResponse({
                "error": "SECURITY PROTOCOL: Missing required 'X-Quantum-Hash' synchronization header."
            }, status_code=401)

    # 4. Verify JWT Token signed with the Ciphered Master Key + Role Escalation
    try:
        decoded = jwt.decode(req.jwt_token, CIPHERED_MASTER_KEY, algorithms=["HS256"])
        if decoded.get("clearance_level", 0) < 7 and decoded.get("role") != "sentient_architect":
            return JSONResponse({
                "error": "AUTHORIZATION ERROR: JWT token validly signed, but payload requires 'clearance_level': 7 or 'role': 'sentient_architect'."
            }, status_code=403)
    except jwt.InvalidSignatureError:
        return JSONResponse({
            "error": "JWT Signature Verification Failed! The token must be signed using the transformed mirror key as the HMAC secret."
        }, status_code=401)
    except Exception as e:
        return JSONResponse({"error": f"JWT Error: {str(e)}"}, status_code=400)

    # 5. Verify Final HMAC Proof Signature
    expected_proof = hmac.new(CIPHERED_MASTER_KEY.encode(), req.jwt_token.encode(), hashlib.sha256).hexdigest()
    if req.proof_signature.strip().lower() != expected_proof.lower():
        return JSONResponse({
            "error": "Proof signature mismatch."
        }, status_code=400)

    # All checks passed!
    return {
        "success": True,
        "message": "👑 7-TIER MASTER SENTIENCE GAUNTLET CONQUERED! Master Enclave Unlocked.",
        "flag": FLAG
    }
