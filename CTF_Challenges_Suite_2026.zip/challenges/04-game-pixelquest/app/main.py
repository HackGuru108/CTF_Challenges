import os
import json
import base64
import hashlib
from fastapi import FastAPI, Request, Response, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

app = FastAPI(title="PixelQuest: Cyber Dungeon RPG")
templates = Jinja2Templates(directory=os.path.join(os.path.dirname(__file__), "templates"))

FLAG = os.getenv("FLAG", "CTF{r3tr0_g4m3_l0g1c_pwn3d_2026}")
SECRET_KEY = "pixel_goblin_secret"

ITEMS_CATALOG = {
    "health_potion": {"name": "Healing Elixir", "price": 10, "type": "consumable", "hp": 50, "icon": "fa-flask"},
    "iron_sword": {"name": "Steel Longsword", "price": 100, "type": "weapon", "atk": 25, "icon": "fa-khanda"},
    "dragon_armor": {"name": "Dragonscale Aegis", "price": 500, "type": "armor", "def": 50, "icon": "fa-shield-halved"},
    "mythic_root_flag": {"name": "Ancient Crown of Root", "price": 1000000, "type": "artifact", "icon": "fa-crown"}
}

MONSTERS = {
    "goblin": {"name": "Cave Goblin", "hp": 30, "atk": 5, "reward_gold": 15, "reward_xp": 20},
    "orc": {"name": "Orc Berserker", "hp": 120, "atk": 20, "reward_gold": 60, "reward_xp": 80},
    "dragon": {"name": "Cyber Dragon Overlord", "hp": 999999, "atk": 9999, "reward_gold": 500000, "reward_xp": 99999}
}

# In-memory session store for demo simplicity
SESSIONS = {}

def get_or_create_session(session_id: str):
    if session_id not in SESSIONS:
        SESSIONS[session_id] = {
            "name": "CyberKnight",
            "level": 1,
            "hp": 100,
            "max_hp": 100,
            "atk": 15,
            "gold": 50,
            "inventory": {
                "health_potion": 2
            },
            "logs": ["Welcome to PixelQuest! Explore the dungeon or trade with the merchant."]
        }
    return SESSIONS[session_id]

class BuyRequest(BaseModel):
    item_id: str
    quantity: int = 1

class BattleRequest(BaseModel):
    monster_id: str

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {
        "request": request,
        "catalog": ITEMS_CATALOG,
        "monsters": MONSTERS
    })

@app.get("/api/state")
async def get_state(request: Request):
    session_id = request.cookies.get("session_id", "guest_hero")
    player = get_or_create_session(session_id)
    response = JSONResponse({
        "player": player,
        "catalog": ITEMS_CATALOG,
        "monsters": MONSTERS
    })
    if "session_id" not in request.cookies:
        response.set_cookie("session_id", "guest_hero")
    return response

@app.post("/api/shop/buy")
async def buy_item(req: BuyRequest, request: Request):
    session_id = request.cookies.get("session_id", "guest_hero")
    player = get_or_create_session(session_id)

    if req.item_id not in ITEMS_CATALOG:
        return JSONResponse({"error": "Unknown item in catalog."}, status_code=400)

    item = ITEMS_CATALOG[req.item_id]
    
    # VULNERABILITY: Missing validation for negative quantity (req.quantity > 0)
    # If quantity is -100, total_cost = -100 * 100 = -10000
    # player["gold"] -= (-10000) adds 10,000 gold to the player!
    total_cost = item["price"] * req.quantity

    if player["gold"] < total_cost:
        return JSONResponse({
            "error": f"Insufficient gold! You have {player['gold']}G but need {total_cost}G."
        }, status_code=400)

    player["gold"] -= total_cost
    current_qty = player["inventory"].get(req.item_id, 0)
    new_qty = current_qty + req.quantity
    
    if new_qty > 0:
        player["inventory"][req.item_id] = new_qty
    elif req.item_id in player["inventory"]:
        del player["inventory"][req.item_id]

    player["logs"].append(f"Bought {req.quantity}x {item['name']} for {total_cost}G.")
    return {"success": True, "message": f"Purchased {req.quantity}x {item['name']}!", "player": player}

@app.post("/api/shop/claim-flag")
async def claim_flag(request: Request):
    session_id = request.cookies.get("session_id", "guest_hero")
    player = get_or_create_session(session_id)

    # Check if player owns the Ancient Crown of Root
    if player["inventory"].get("mythic_root_flag", 0) >= 1:
        return {
            "success": True,
            "message": "The Grand King bows before the Ancient Crown! Here is your reward:",
            "flag": FLAG
        }
    
    return JSONResponse({
        "error": "You do not possess the 'Ancient Crown of Root' (mythic_root_flag). Visit the merchant!"
    }, status_code=403)

@app.post("/api/battle")
async def battle(req: BattleRequest, request: Request):
    session_id = request.cookies.get("session_id", "guest_hero")
    player = get_or_create_session(session_id)

    if req.monster_id not in MONSTERS:
        return JSONResponse({"error": "Unknown monster."}, status_code=400)

    monster = MONSTERS[req.monster_id]
    
    if player["hp"] <= 0:
        return JSONResponse({"error": "You are unconscious! Drink a potion first."}, status_code=400)

    # Simplified battle simulation
    rounds = []
    monster_hp = monster["hp"]
    player_hp = player["hp"]

    while monster_hp > 0 and player_hp > 0:
        # Player strikes
        damage_to_monster = max(1, player["atk"])
        monster_hp -= damage_to_monster
        rounds.append(f"⚔️ You dealt {damage_to_monster} damage to {monster['name']}.")
        
        if monster_hp <= 0:
            break

        # Monster strikes
        damage_to_player = max(1, monster["atk"])
        player_hp -= damage_to_player
        rounds.append(f"💥 {monster['name']} struck back for {damage_to_player} damage!")

    player["hp"] = max(0, player_hp)

    if monster_hp <= 0:
        player["gold"] += monster["reward_gold"]
        player["logs"].append(f"🏆 Victory against {monster['name']}! Earned {monster['reward_gold']}G.")
        return {
            "victory": True,
            "rounds": rounds[-5:],
            "reward_gold": monster["reward_gold"],
            "player": player
        }
    else:
        player["logs"].append(f"💀 Defeated by {monster['name']}...")
        return {
            "victory": False,
            "rounds": rounds[-5:],
            "player": player
        }

@app.post("/api/reset")
async def reset_game(request: Request):
    session_id = request.cookies.get("session_id", "guest_hero")
    SESSIONS[session_id] = {
        "name": "CyberKnight",
        "level": 1,
        "hp": 100,
        "max_hp": 100,
        "atk": 15,
        "gold": 50,
        "inventory": { "health_potion": 2 },
        "logs": ["Game state reset."]
    }
    return {"success": True, "player": SESSIONS[session_id]}
